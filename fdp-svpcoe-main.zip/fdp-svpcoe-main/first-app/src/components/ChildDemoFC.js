import React from 'react'

export default function ChildDemoFC() {
  return (
    <div>
      <h3>These is the nested Component for App</h3>
      <p>and Child Component for Demo FC</p>
    </div>
  )
}
