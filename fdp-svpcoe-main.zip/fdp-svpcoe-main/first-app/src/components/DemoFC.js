import React from 'react'
import ChildDemoFC from './ChildDemoFC'

export default function DemoFC() {
  return (
    <div>
      <h3>In DemoFC as Separate Fun Component</h3>
      <ChildDemoFC/>
    </div>
  )
}
