import React, { Component } from 'react'

export default class ChildDemoCC extends Component {
  render() {
    return (
      <div>
        <h3>We are in Class Component and it is a Child of DemoCC</h3>
      </div>
    )
  }
}
